import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;


public class TestReadNewick {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "(((6:232.085215[&&NHX:age=0.000000],2:232.085215[&&NHX:age=0.000000])17:11829.723300[&&NHX:age=232.085215],(0:8051.702368[&&NHX:age=0.000000],(7:49.193481[&&NHX:age=0.000000],1:49.193481[&&NHX:age=0.000000])18:8002.508887[&&NHX:age=49.193481])11:4010.106147[&&NHX:age=8051.702368])13:48093.809938[&&NHX:age=12061.808515]," +
				"((5:395.449492[&&NHX:age=0.000000],3:395.449492[&&NHX:age=0.000000])16:4968.396729[&&NHX:age=395.449492],((9:122.586947[&&NHX:age=0.000000],4:122.586947[&&NHX:age=0.000000])12:2232.115040[&&NHX:age=122.586947],8:2354.701987[&&NHX:age=0.000000])14:3009.144234[&&NHX:age=2354.701987])15:54791.772231[&&NHX:age=5363.846221])" +
				"10[&&NHX:age=60155.618452];";

		System.out.println(input);

		String[] inputArray = input.split("\\(|,|\\)");

		System.out.println("" + inputArray.length);

		for(int i = 0; i < inputArray.length; i++){
			System.out.println(inputArray[i]);
		}

		ArrayList<String> temp = new ArrayList<String>();

		for(int i = 0; i < inputArray.length; i++){
			if(inputArray[i].length() > 0){
				temp.add(inputArray[i]);
			}
		}

		System.out.println("" + temp.size());

		Double[][] age = new Double[temp.size() - 1][2];

		for(int i = 0; i < temp.size() - 1; i++){
			String[] currentThing = temp.get(i).split(":|\\[");
			age[i][1] = Double.parseDouble(currentThing[0]);
			age[i][0] = Double.parseDouble(currentThing[1]);
		}


		Arrays.sort(age, new Comparator<Double[]>() {
			@Override
			public int compare(final Double[] entry1, final Double[] entry2){
				final Double age1 = entry1[0];
				final Double age2 = entry2[0];

				int value = -1;

				if (age1 > age2){
					value = 1;
				} else if (age1 == age2){
					value = 0;
				}

				return value;
			}

		});



		for(int i = 0; i < temp.size() - 1; i++){
			System.out.println("" + age[i][0] + "\t" + age[i][1]);
		}
		
		Double numTaxa = ((double)temp.size() + 1) / 2;
		
		int[][] tree = new int[(temp.size() - numTaxa.intValue())][3];
		
		for(int i = 0; i < tree.length; i++){
			tree[i][0] = i + numTaxa.intValue();
		}
		
		for(int i = 0; i < temp.size() - 1; i++){
			if(age[i][1] < numTaxa){
				continue;
			}
			
			int index = input.indexOf("" + age[i][1].intValue() + ":");
			
			System.out.println("" + age[i][1]);
				
			int parens = 0;
			
			for (int j = index - 1; j >= 0; j--){
				if (input.charAt(j) == ')'){
					parens++;
				}
				if (input.charAt(j) == '('){
					parens--;
				}
				if(parens == 0 && input.charAt(j) == ','){
					for(int k = j - 1; k >= 0; k--){
						
					}
				}
			}
		}
	}
}
